import React from 'react'
import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  ClipboardList,
  Search,
  FolderKanban,
  Users,
  Scale,
  Compass,
  Link2
} from 'lucide-react'

const NAV_ITEMS = [
  { to: '/', label: 'Painel Geral', icon: LayoutDashboard, end: true },
  { to: '/crescente', label: 'Crescente (Tarefas)', icon: ClipboardList },
  { to: '/busca-ativa', label: 'Busca Ativa', icon: Search },
  { to: '/projetos', label: 'Projetos & Ações', icon: FolderKanban },
  { to: '/equipe', label: 'Equipe', icon: Users },
  { to: '/legislacao', label: 'Legislação & Documentos', icon: Scale },
  { to: '/indicadores', label: 'Indicadores', icon: Compass },
  { to: '/integracoes', label: 'Outras Plataformas', icon: Link2 }
]

export default function Sidebar() {
  return (
    <aside className="w-64 shrink-0 bg-night text-paper flex flex-col h-screen sticky top-0">
      <div className="px-6 pt-7 pb-6 border-b border-white/10">
        <p className="font-mono text-[11px] tracking-[0.2em] text-moon uppercase">Gestão Escolar</p>
        <h1 className="font-display text-xl leading-snug mt-1">
          E.M. Regina Celi<br />da Silva Cerdeira
        </h1>
        <p className="text-xs text-paper/50 mt-2">Jardim Primavera · Duque de Caxias</p>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                isActive
                  ? 'bg-white/10 text-white font-medium'
                  : 'text-paper/70 hover:bg-white/5 hover:text-white'
              }`
            }
          >
            <Icon size={17} strokeWidth={1.75} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="px-6 py-5 border-t border-white/10">
        <p className="text-xs text-paper/40 leading-relaxed">
          Direção: Mário Júnior Martins<br />
          Ano letivo 2026
        </p>
      </div>
    </aside>
  )
}
