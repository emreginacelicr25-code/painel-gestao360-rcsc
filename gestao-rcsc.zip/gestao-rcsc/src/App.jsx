import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import PainelGeral from './pages/PainelGeral.jsx'
import Crescente from './pages/Crescente.jsx'
import EmConstrucao from './pages/EmConstrucao.jsx'

export default function App() {
  return (
    <div className="flex min-h-screen bg-paper">
      <Sidebar />
      <main className="flex-1 p-8 md:p-10 overflow-x-hidden">
        <Routes>
          <Route path="/" element={<PainelGeral />} />
          <Route path="/crescente" element={<Crescente />} />
          <Route
            path="/busca-ativa"
            element={
              <EmConstrucao
                titulo="Busca Ativa Escolar"
                descricao="Kanban com as 5 etapas do fluxo de Busca Ativa (identificação → contato via WhatsApp → convocatória formal → mobilização comunitária → acionamento do Conselho Tutelar), planilha por turma e indicadores de resposta."
              />
            }
          />
          <Route
            path="/projetos"
            element={
              <EmConstrucao
                titulo="Projetos & Ações"
                descricao="Linha do tempo bimestral com todos os projetos do Plano de Ação (Gincana Inclusiva, PROEC, Semanas temáticas, Olimpíadas da Inclusão, Festa da Alegria etc.), cada um com etapas, responsáveis e checklist."
              />
            }
          />
          <Route
            path="/equipe"
            element={
              <EmConstrucao
                titulo="Equipe"
                descricao="Cards com foto, função, regime de dias e atribuição central de cada profissional, com acesso direto ao perfil, histórico de atribuições e documentos vinculados."
              />
            }
          />
          <Route
            path="/legislacao"
            element={
              <EmConstrucao
                titulo="Legislação & Documentos"
                descricao="Base pesquisável com LDB, ECA, BNCC, leis municipais (2.864/2017, 2.713/2015, 3.170/2021), deliberações do CME/DC e a Resolução 003/2025-SME de matrícula, cada uma com resumo, base legal e PDF anexado."
              />
            }
          />
          <Route
            path="/indicadores"
            element={
              <EmConstrucao
                titulo="Indicadores"
                descricao="Painel completo dos indicadores do Plano de Ação Anual (frequência, PEIs, relatórios, AAIs, atas de COC) com gráficos de evolução bimestral."
              />
            }
          />
          <Route
            path="/integracoes"
            element={
              <EmConstrucao
                titulo="Outras Plataformas"
                descricao="Acesso direto ao rcsc-triagem, transporte-escolar, plataforma-inclusao-rcsc e central-documentos-rcsc, sem duplicar dados — este painel consome e exibe."
              />
            }
          />
        </Routes>
      </main>
    </div>
  )
}
