import React from 'react'
import { Hammer } from 'lucide-react'

export default function EmConstrucao({ titulo, descricao }) {
  return (
    <div className="max-w-2xl">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-moon/20 flex items-center justify-center">
          <Hammer size={18} className="text-moon-deep" />
        </div>
        <h2 className="font-display text-2xl text-night">{titulo}</h2>
      </div>
      <p className="text-night/70 leading-relaxed">{descricao}</p>
      <p className="text-sm text-night/40 mt-4 font-mono">
        Módulo planejado — entra na próxima etapa de construção da plataforma.
      </p>
    </div>
  )
}
